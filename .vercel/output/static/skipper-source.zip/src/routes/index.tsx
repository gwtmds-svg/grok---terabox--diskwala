import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState, type ReactNode } from "react";
import { ArrowRight, Clock, Settings2, Shield, Zap } from "lucide-react";
import { resolveLink } from "@/lib/extractors/resolve.functions";
import type { ResolveResult, ResolvedFile } from "@/lib/extractors/types";
import { detectHost } from "@/lib/extractors/parse-url";
import {
  clearHistory,
  loadCookie,
  loadHistory,
  pushHistory,
  saveCookie,
  type HistoryItem,
} from "@/lib/history";
import { FileCard } from "@/components/file-card";
import { StreamPlayer } from "@/components/player";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/")({ component: Home });

const EXAMPLES = [
  {
    label: "TeraBox sample",
    url: "https://1024tera.com/s/16-BFJ6KJhZEBpv_vhNsD6w",
  },
  {
    label: "Diskwala sample",
    url: "https://www.diskwala.com/app/6a8d41a406ba7ea03d30ccb1",
  },
];

function Home() {
  const [url, setUrl] = useState("");
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<ResolveResult | null>(null);
  const [playing, setPlaying] = useState<ResolvedFile | null>(null);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [cookie, setCookie] = useState(() => (typeof window === "undefined" ? "" : loadCookie()));
  const [history, setHistory] = useState<HistoryItem[]>(() =>
    typeof window === "undefined" ? [] : loadHistory(),
  );

  const host = useMemo(() => (url.trim() ? detectHost(url) : "unknown"), [url]);

  async function run(nextUrl = url) {
    const trimmed = nextUrl.trim();
    if (!trimmed) return;
    setUrl(trimmed);
    setBusy(true);
    setResult(null);
    try {
      const data = await resolveLink({ data: { url: trimmed, cookie } });
      setResult(data);
      if (data.ok) {
        setHistory(
          pushHistory({
            url: trimmed,
            title: data.title,
            host: data.host,
            at: Date.now(),
            fileCount: data.files.length,
          }),
        );
      }
    } catch (err) {
      setResult({
        ok: false,
        host: detectHost(trimmed),
        inputUrl: trimmed,
        error: err instanceof Error ? err.message : "Resolve failed",
        elapsedMs: 0,
      });
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <header className="mx-auto flex max-w-3xl items-center justify-between px-5 py-6">
        <Link to="/" className="font-display text-xl tracking-tight text-fg">
          Skipper
        </Link>
        <nav className="flex items-center gap-1">
          <Link
            to="/guide"
            className="inline-flex h-11 items-center px-3 text-sm text-muted hover:text-fg"
          >
            How it works
          </Link>
          <button
            type="button"
            onClick={() => setSettingsOpen((v) => !v)}
            className="inline-flex size-11 items-center justify-center rounded-md text-muted hover:bg-elevated hover:text-fg"
            aria-label="Settings"
          >
            <Settings2 className="size-5" />
          </button>
        </nav>
      </header>

      <main className="mx-auto flex max-w-3xl flex-col gap-10 px-5 pb-24">
        <section className="flex flex-col gap-5 pt-4">
          <p className="text-sm uppercase tracking-[0.18em] text-muted">TeraBox · Diskwala</p>
          <h1 className="font-display text-4xl leading-tight tracking-tight text-fg sm:text-5xl">
            Paste the link.
            <br />
            Skip the ads.
          </h1>
          <p className="max-w-xl text-base leading-relaxed text-muted">
            Public share pages bury the file behind timers and popups. Skipper reads the share
            API on the server, lists every file, and lets you play or download from here.
          </p>
        </section>

        {settingsOpen ? (
          <section className="rounded-lg border border-border bg-surface p-5">
            <h2 className="text-sm font-medium text-fg">Optional TeraBox cookie</h2>
            <p className="mt-2 text-sm leading-relaxed text-muted">
              Listing and in-browser playback do not need an account. Original-quality files
              (the exact upload, not the 480p stream) need an <code className="font-mono">ndus</code>{" "}
              cookie from a logged-in TeraBox session. It stays in this browser only.
            </p>
            <textarea
              value={cookie}
              onChange={(e) => setCookie(e.target.value)}
              placeholder="ndus=Y……"
              rows={3}
              className="mt-4 w-full resize-y rounded-md border border-border bg-bg px-3 py-2 font-mono text-sm text-fg outline-none focus:outline-2 focus:outline-accent"
            />
            <div className="mt-3 flex gap-2">
              <Button
                type="button"
                size="sm"
                onClick={() => {
                  saveCookie(cookie);
                  setSettingsOpen(false);
                }}
              >
                Save
              </Button>
              <Button
                type="button"
                size="sm"
                variant="ghost"
                onClick={() => {
                  setCookie("");
                  saveCookie("");
                }}
              >
                Clear
              </Button>
            </div>
          </section>
        ) : null}

        <form
          className="flex flex-col gap-3"
          onSubmit={(e) => {
            e.preventDefault();
            void run();
          }}
        >
          <label className="text-sm text-muted" htmlFor="share-url">
            Share link
          </label>
          <div className="flex flex-col gap-3 sm:flex-row">
            <input
              id="share-url"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="https://1024tera.com/s/… or https://diskwala.com/app/…"
              autoComplete="off"
              spellCheck={false}
              className="h-12 min-w-0 flex-1 rounded-md border border-border bg-surface px-4 text-base text-fg outline-none placeholder:text-subtle focus:outline-2 focus:outline-offset-0 focus:outline-accent"
            />
            <Button type="submit" size="lg" disabled={busy || !url.trim()} className="sm:w-40">
              {busy ? "Opening…" : "Open"}
              {!busy ? <ArrowRight className="size-4" /> : null}
            </Button>
          </div>
          <p className="text-xs text-subtle">
            {host === "unknown" && url.trim()
              ? "Host not recognised yet."
              : host === "terabox"
                ? "TeraBox share — listing is anonymous and usually under a second."
                : host === "diskwala"
                  ? "Diskwala share — AppiCrypt means this path uses a headless browser and takes a few seconds."
                  : "Supports TeraBox and Diskwala public links."}
          </p>
        </form>

        <div className="flex flex-wrap gap-2">
          {EXAMPLES.map((ex) => (
            <button
              key={ex.url}
              type="button"
              onClick={() => void run(ex.url)}
              className="h-9 rounded-full border border-border px-3 text-sm text-muted hover:border-accent hover:text-fg"
            >
              {ex.label}
            </button>
          ))}
        </div>

        {busy ? (
          <div className="flex flex-col gap-3" aria-live="polite">
            <div className="h-28 animate-pulse rounded-lg bg-surface" />
            <p className="text-sm text-muted">Reading the share…</p>
          </div>
        ) : null}

        {result && !result.ok ? (
          <div className="rounded-lg border border-border bg-surface p-5">
            <p className="font-medium text-fg">{result.error}</p>
            {result.hint ? <p className="mt-2 text-sm leading-relaxed text-muted">{result.hint}</p> : null}
          </div>
        ) : null}

        {result && result.ok ? (
          <section className="flex flex-col gap-4">
            <div className="flex flex-wrap items-end justify-between gap-3">
              <div>
                <p className="text-xs uppercase tracking-widest text-muted">{result.host}</p>
                <h2 className="mt-1 font-display text-2xl text-fg">{result.title}</h2>
              </div>
              <p className="text-sm text-subtle">{result.elapsedMs} ms</p>
            </div>
            {result.warnings.map((w) => (
              <p key={w} className="text-sm text-muted">
                {w}
              </p>
            ))}
            <div className="flex flex-col gap-3">
              {result.files.map((file) => (
                <FileCard key={file.id + file.path} file={file} cookie={cookie} onPlay={setPlaying} />
              ))}
            </div>
          </section>
        ) : null}

        {history.length > 0 ? (
          <section className="flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <h2 className="flex items-center gap-2 text-sm font-medium text-muted">
                <Clock className="size-4" />
                Recent
              </h2>
              <button
                type="button"
                className="text-sm text-subtle hover:text-fg"
                onClick={() => {
                  clearHistory();
                  setHistory([]);
                }}
              >
                Clear
              </button>
            </div>
            <ul className="flex flex-col gap-1">
              {history.map((h) => (
                <li key={h.url}>
                  <button
                    type="button"
                    onClick={() => void run(h.url)}
                    className={cn(
                      "flex w-full items-center justify-between gap-3 rounded-md px-3 py-3 text-left hover:bg-surface",
                    )}
                  >
                    <span className="min-w-0 truncate text-sm text-fg">{h.title}</span>
                    <span className="shrink-0 text-xs uppercase text-subtle">{h.host}</span>
                  </button>
                </li>
              ))}
            </ul>
          </section>
        ) : null}

        <section className="grid gap-4 sm:grid-cols-3">
          <Fact
            icon={<Zap className="size-4" />}
            title="Anonymous listing"
            body="TeraBox /share/list returns names, sizes and thumbs with no login."
          />
          <Fact
            icon={<Shield className="size-4" />}
            title="Files stay on their CDN"
            body="We mint stream URLs. Bytes go from TeraBox or Diskwala to you, not through a stash."
          />
          <Fact
            icon={<Settings2 className="size-4" />}
            title="Cookie is optional"
            body="Only original-quality TeraBox downloads need an ndus cookie. Playback does not."
          />
        </section>
        <p className="text-center text-sm text-subtle">
          <a href="/skipper-source.zip" className="hover:text-fg">
            Download source
          </a>
          {" · "}
          <a href="/docs/AI_HANDOFF_PROMPT.md" className="hover:text-fg">
            Handoff for the next builder
          </a>
          {" · "}
          <a href="/docs/COMPLETE_BUILD_GUIDE.md" className="hover:text-fg">
            A–Z guide
          </a>
        </p>
      </main>

      {playing ? <StreamPlayer file={playing} onClose={() => setPlaying(null)} /> : null}
    </div>
  );
}

function Fact({ icon, title, body }: { icon: ReactNode; title: string; body: string }) {
  return (
    <div className="rounded-lg border border-border bg-surface p-4">
      <div className="text-muted">{icon}</div>
      <h3 className="mt-3 text-sm font-medium text-fg">{title}</h3>
      <p className="mt-1 text-sm leading-relaxed text-muted">{body}</p>
    </div>
  );
}
