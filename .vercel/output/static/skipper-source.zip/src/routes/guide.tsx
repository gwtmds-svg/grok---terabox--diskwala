import { createFileRoute, Link } from "@tanstack/react-router";

export const Route = createFileRoute("/guide")({ component: Guide });

function Guide() {
  return (
    <div className="min-h-dvh bg-bg text-fg">
      <header className="mx-auto flex max-w-3xl items-center justify-between px-5 py-6">
        <Link to="/" className="font-display text-xl tracking-tight">
          Skipper
        </Link>
        <Link to="/" className="inline-flex h-11 items-center text-sm text-muted hover:text-fg">
          Back
        </Link>
      </header>
      <article className="mx-auto flex max-w-3xl flex-col gap-8 px-5 pb-24 text-base leading-relaxed text-muted">
        <h1 className="font-display text-4xl tracking-tight text-fg">How Skipper works</h1>
        <p>
          Skipper is a share-link resolver. You paste a public TeraBox or Diskwala URL. The
          server talks to the host’s own APIs, skips the ad wall, and returns the file list
          plus play/download handles. Nothing is stored on an account — history lives in this
          browser.
        </p>

        <h2 className="font-display text-2xl text-fg">Do I need to log in?</h2>
        <p>
          No, not for listing files or watching the in-browser stream. TeraBox publishes share
          metadata on <code className="font-mono text-fg">/share/list</code> with only a
          guest cookie (csrfToken, browserid, TSID) that the share page itself sets.
        </p>
        <p>
          Original-quality download of the exact uploaded file is the one step that TeraBox
          gates. Their <code className="font-mono text-fg">/api/sharedownload</code> endpoint
          returns <code className="font-mono">errno -6 need verify_v2</code> without a live{" "}
          <code className="font-mono text-fg">ndus</code> cookie from a logged-in account.
          That cookie is optional and pasted in Settings. You do not need a pool of 10
          accounts for the app to function — a pool is only a reliability tactic if you serve
          original downloads at scale.
        </p>

        <h2 className="font-display text-2xl text-fg">TeraBox, step by step</h2>
        <ol className="list-decimal space-y-2 pl-5">
          <li>Parse the share code (surl). Strip a leading 1 from /s/1XXXX links.</li>
          <li>GET the share HTML, collect Set-Cookie, extract jsToken from the page script.</li>
          <li>
            GET /share/list?app_id=250528&shorturl=…&root=1 — errno 0 returns filename, size,
            duration, thumbs, fs_id, share_id, uk.
          </li>
          <li>
            For video, GET /share/streaming with sign = sha1(uk + shareid + fid + unixTime).
            Confirmed live without login. HLS is rewritten through /api/hls and /api/seg so
            the player is not blocked by CDN CORS.
          </li>
          <li>
            If an ndus cookie is present, POST /api/sharedownload for the original dlink and
            follow the CDN redirect.
          </li>
        </ol>

        <h2 className="font-display text-2xl text-fg">Diskwala</h2>
        <p>
          Diskwala is a React SPA. File metadata lives at{" "}
          <code className="font-mono text-fg">ddudapidd.diskwala.com/api/v1/file/temp_info</code>{" "}
          with body <code className="font-mono">{"{ id }"}</code>. Every call must carry an
          AppiCrypt header minted by WASM in the real page. Unsigned calls return 400 Missing
          Appicrypt header; replayed headers 403. Skipper therefore loads /app/:id in
          Chromium and intercepts the JSON. The sample id you provided currently 404s (file
          removed) — a live id still works.
        </p>

        <h2 className="font-display text-2xl text-fg">What is finished vs next</h2>
        <ul className="list-disc space-y-2 pl-5">
          <li>TeraBox listing — done, no login, typically under 2 seconds.</li>
          <li>TeraBox HLS play + stream download — done, no login.</li>
          <li>Optional ndus original download — wired, needs your cookie.</li>
          <li>Diskwala intercept — wired; sample link is expired.</li>
          <li>Password-protected TeraBox shares, recursive deep folders, cookie pool rotation — documented in the handoff, not built yet.</li>
        </ul>

        <p>
          The full engineering brief for the next builder lives in{" "}
          <a href="/docs/AI_HANDOFF_PROMPT.md" className="text-fg underline">
            docs/AI_HANDOFF_PROMPT.md
          </a>{" "}
          and the A–Z runbook in{" "}
          <a href="/docs/COMPLETE_BUILD_GUIDE.md" className="text-fg underline">
            docs/COMPLETE_BUILD_GUIDE.md
          </a>
          . A source archive is at{" "}
          <a href="/skipper-source.zip" className="text-fg underline">
            skipper-source.zip
          </a>
          .
        </p>
      </article>
    </div>
  );
}
