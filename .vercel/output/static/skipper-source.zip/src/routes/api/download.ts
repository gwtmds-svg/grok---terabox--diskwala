import { createFileRoute } from "@tanstack/react-router";
import { fetchTeraboxDlink, fetchTeraboxPlaylist } from "@/lib/extractors/terabox";

const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";

export const Route = createFileRoute("/api/download")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const u = new URL(request.url);
        const mode = u.searchParams.get("mode") ?? "stream";
        const name = u.searchParams.get("name") ?? "file";
        const uk = u.searchParams.get("uk") ?? "";
        const shareId = u.searchParams.get("shareid") ?? "";
        const fid = u.searchParams.get("fid") ?? "";
        const cookie = u.searchParams.get("cookie") ?? "";
        const direct = u.searchParams.get("direct") ?? "";

        if (direct) {
          return proxyFile(direct, name);
        }

        if (mode === "original" && cookie && uk && shareId && fid) {
          const dlink = await fetchTeraboxDlink({ uk, shareId, fsId: fid, cookie });
          if (dlink) return proxyFile(dlink, name);
        }

        if (!uk || !shareId || !fid) {
          return Response.json({ error: "missing file ids" }, { status: 400 });
        }

        const playlist = await fetchTeraboxPlaylist(uk, shareId, fid);
        if ("error" in playlist) {
          return Response.json({ error: playlist.error }, { status: 502 });
        }
        const segments = playlist.playlist.split("\n").filter((l) => l.startsWith("http"));
        if (!segments.length) {
          return Response.json({ error: "empty playlist" }, { status: 502 });
        }
        const filename = name.replace(/[^\w.\- ()[\]]+/g, "_");
        const stream = concatSegments(segments);
        return new Response(stream, {
          headers: {
            "content-type": "video/mp2t",
            "content-disposition": `attachment; filename="${filename.replace(/\.[^.]+$/, "")}.ts"`,
            "cache-control": "no-store",
          },
        });
      },
    },
  },
});

async function proxyFile(url: string, name: string): Promise<Response> {
  const res = await fetch(url, {
    headers: { "user-agent": UA, referer: "https://www.1024tera.com/" },
    redirect: "follow",
  });
  const headers = new Headers();
  headers.set("content-type", res.headers.get("content-type") || "application/octet-stream");
  const len = res.headers.get("content-length");
  if (len) headers.set("content-length", len);
  const safe = name.replace(/[^\w.\- ()[\]]+/g, "_");
  headers.set("content-disposition", `attachment; filename="${safe}"`);
  headers.set("cache-control", "no-store");
  return new Response(res.body, { status: res.status, headers });
}

function concatSegments(urls: string[]): ReadableStream<Uint8Array> {
  return new ReadableStream({
    async start(controller) {
      try {
        for (const url of urls) {
          const res = await fetch(url, {
            headers: { "user-agent": UA, referer: "https://www.1024tera.com/" },
          });
          if (!res.body) continue;
          const reader = res.body.getReader();
          for (;;) {
            const { done, value } = await reader.read();
            if (done) break;
            if (value) controller.enqueue(value);
          }
        }
        controller.close();
      } catch (err) {
        controller.error(err);
      }
    },
  });
}
