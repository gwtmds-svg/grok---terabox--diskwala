import { createFileRoute } from "@tanstack/react-router";

const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";

export const Route = createFileRoute("/api/seg")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const target = new URL(request.url).searchParams.get("u");
        if (!target || !isAllowedCdn(target)) {
          return new Response("blocked", { status: 400 });
        }
        const range = request.headers.get("range");
        const res = await fetch(target, {
          headers: {
            "user-agent": UA,
            referer: "https://www.1024tera.com/",
            ...(range ? { range } : {}),
          },
        });
        const headers = new Headers();
        for (const k of ["content-type", "content-length", "content-range", "accept-ranges"]) {
          const v = res.headers.get(k);
          if (v) headers.set(k, v);
        }
        headers.set("cache-control", "public, max-age=120");
        headers.set("access-control-allow-origin", "*");
        return new Response(res.body, { status: res.status, headers });
      },
    },
  },
});

function isAllowedCdn(url: string): boolean {
  try {
    const h = new URL(url).hostname.toLowerCase();
    return (
      h.endsWith("freeterabox.com") ||
      h.endsWith("terabox.com") ||
      h.endsWith("1024tera.com") ||
      h.endsWith("teraboxcdn.com") ||
      h.endsWith("diskwala.com") ||
      h.includes("baidupcs.com")
    );
  } catch {
    return false;
  }
}
