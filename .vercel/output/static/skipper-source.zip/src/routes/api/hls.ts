import { createFileRoute } from "@tanstack/react-router";
import { fetchTeraboxPlaylist } from "@/lib/extractors/terabox";

export const Route = createFileRoute("/api/hls")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const u = new URL(request.url);
        const uk = u.searchParams.get("uk") ?? "";
        const shareId = u.searchParams.get("shareid") ?? "";
        const fid = u.searchParams.get("fid") ?? "";
        const type = u.searchParams.get("type") ?? "M3U8_AUTO_480";
        if (!uk || !shareId || !fid) {
          return Response.json({ error: "uk, shareid, fid required" }, { status: 400 });
        }
        const result = await fetchTeraboxPlaylist(uk, shareId, fid, type);
        if ("error" in result) {
          return Response.json({ error: result.error }, { status: 502 });
        }
        const origin = u.origin;
        const rewritten = result.playlist
          .split("\n")
          .map((line) => {
            if (line.startsWith("http")) {
              return `${origin}/api/seg?u=${encodeURIComponent(line)}`;
            }
            return line;
          })
          .join("\n");
        return new Response(rewritten, {
          headers: {
            "content-type": "application/vnd.apple.mpegurl",
            "cache-control": "no-store",
            "access-control-allow-origin": "*",
          },
        });
      },
    },
  },
});
