import { createFileRoute } from "@tanstack/react-router";

const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";

export const Route = createFileRoute("/api/thumb")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const target = new URL(request.url).searchParams.get("u");
        if (!target) return new Response("missing", { status: 400 });
        let host = "";
        try {
          host = new URL(target).hostname.toLowerCase();
        } catch {
          return new Response("bad url", { status: 400 });
        }
        if (!host.endsWith("1024tera.com") && !host.endsWith("terabox.com") && !host.endsWith("teraboxcdn.com") && !host.endsWith("diskwala.com")) {
          return new Response("blocked", { status: 400 });
        }
        const res = await fetch(target, {
          headers: { "user-agent": UA, referer: "https://www.1024tera.com/" },
        });
        return new Response(res.body, {
          status: res.status,
          headers: {
            "content-type": res.headers.get("content-type") || "image/jpeg",
            "cache-control": "public, max-age=3600",
          },
        });
      },
    },
  },
});
