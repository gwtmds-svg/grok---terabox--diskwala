import { useEffect, useRef } from "react";
import Hls from "hls.js";
import type { ResolvedFile } from "@/lib/extractors/types";

export function StreamPlayer({ file, onClose }: { file: ResolvedFile; onClose: () => void }) {
  const ref = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    const video = ref.current;
    if (!video) return;

    if (file.directUrl && /\.(mp4|webm|mkv)(\?|$)/i.test(file.directUrl)) {
      video.src = `/api/seg?u=${encodeURIComponent(file.directUrl)}`;
      return () => {
        video.removeAttribute("src");
      };
    }

    if (!file.uk || !file.shareId || !file.fsId) return;
    const src = `/api/hls?uk=${encodeURIComponent(file.uk)}&shareid=${encodeURIComponent(file.shareId)}&fid=${encodeURIComponent(file.fsId)}`;

    if (video.canPlayType("application/vnd.apple.mpegurl")) {
      video.src = src;
      return () => video.removeAttribute("src");
    }

    if (Hls.isSupported()) {
      const hls = new Hls({ enableWorker: true, lowLatencyMode: false });
      hls.loadSource(src);
      hls.attachMedia(video);
      return () => {
        hls.destroy();
      };
    }
  }, [file]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-bg/80 p-4">
      <div className="flex w-full max-w-4xl flex-col gap-3 rounded-xl bg-surface p-4 shadow-2xl">
        <div className="flex items-start justify-between gap-4">
          <div className="min-w-0">
            <p className="truncate font-display text-lg text-fg">{file.name}</p>
            <p className="text-sm text-muted">In-browser stream · no ads</p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="size-11 shrink-0 rounded-md text-muted hover:bg-elevated hover:text-fg"
            aria-label="Close player"
          >
            Close
          </button>
        </div>
        <video
          ref={ref}
          controls
          autoPlay
          playsInline
          className="aspect-video w-full rounded-md bg-bg"
        />
      </div>
    </div>
  );
}
