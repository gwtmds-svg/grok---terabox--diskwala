import { createHash } from "node:crypto";
import type { ResolveResult, ResolvedFile } from "./types";
import { extractTeraSurl } from "./parse-url";

const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";
const APP_ID = "250528";
const ORIGIN = "https://www.1024tera.com";

type TeraListItem = {
  category?: string;
  fs_id: string | number;
  isdir: string | number;
  path: string;
  server_filename: string;
  size: string | number;
  md5?: string;
  thumbs?: { url1?: string; url2?: string; url3?: string; icon?: string };
  width?: number;
  height?: number;
  duration?: number;
  dlink?: string;
};

type TeraListJson = {
  errno: number;
  show_msg?: string;
  title?: string;
  share_id?: number | string;
  uk?: number | string;
  list?: TeraListItem[];
};

function cookieHeaderFromResponse(res: Response): string {
  const raw = typeof res.headers.getSetCookie === "function" ? res.headers.getSetCookie() : [];
  const pairs = raw.map((c) => c.split(";")[0]).filter(Boolean);
  return pairs.join("; ");
}

function extractJsToken(html: string): string {
  const decoded = decodeURIComponent(html);
  const m =
    decoded.match(/fn\("([A-F0-9]{32,})"\)/) ||
    html.match(/fn%28%22([A-F0-9]{32,})%22/) ||
    html.match(/jsToken["'\s:=]+["']([A-F0-9]{32,})/);
  return m?.[1] ?? "";
}

async function fetchText(
  url: string,
  init: { cookie?: string; referer?: string; method?: string; body?: string } = {},
): Promise<{ status: number; text: string; cookie: string; json: unknown }> {
  const res = await fetch(url, {
    method: init.method ?? "GET",
    headers: {
      "user-agent": UA,
      accept: "application/json,text/html,*/*",
      referer: init.referer ?? `${ORIGIN}/`,
      cookie: init.cookie ?? "",
      ...(init.body ? { "content-type": "application/x-www-form-urlencoded" } : {}),
    },
    body: init.body,
    redirect: "follow",
  });
  const text = await res.text();
  let json: unknown = null;
  try {
    json = JSON.parse(text);
  } catch {
    json = null;
  }
  return { status: res.status, text, cookie: cookieHeaderFromResponse(res), json };
}

function mimeHint(name: string, isDir: boolean, category?: string): ResolvedFile["mimeHint"] {
  if (isDir) return "folder";
  if (category === "1") return "video";
  if (category === "2") return "audio";
  if (category === "3") return "image";
  const ext = name.split(".").pop()?.toLowerCase() ?? "";
  if (["mp4", "mkv", "avi", "mov", "webm", "flv", "m4v", "ts"].includes(ext)) return "video";
  if (["mp3", "flac", "wav", "aac", "m4a", "ogg"].includes(ext)) return "audio";
  if (["jpg", "jpeg", "png", "gif", "webp", "bmp"].includes(ext)) return "image";
  return "file";
}

function toFile(
  item: TeraListItem,
  ctx: { shareId: string; uk: string; surl: string },
): ResolvedFile {
  const isDir = String(item.isdir) === "1";
  const name = item.server_filename || item.path.split("/").pop() || "file";
  const hint = mimeHint(name, isDir, item.category);
  return {
    id: String(item.fs_id),
    name,
    size: Number(item.size) || 0,
    isDir,
    path: item.path,
    mimeHint: hint,
    thumbnail: item.thumbs?.url3 || item.thumbs?.url2 || item.thumbs?.url1,
    duration: item.duration ? Number(item.duration) : undefined,
    width: item.width,
    height: item.height,
    md5: item.md5,
    fsId: String(item.fs_id),
    shareId: ctx.shareId,
    uk: ctx.uk,
    surl: ctx.surl,
    host: "terabox",
    directUrl: item.dlink,
    originalReady: Boolean(item.dlink),
    canStream: !isDir && hint === "video",
  };
}

async function listDir(
  surl: string,
  cookie: string,
  jsToken: string,
  dir?: string,
): Promise<TeraListJson> {
  const u = new URL(`${ORIGIN}/share/list`);
  u.searchParams.set("app_id", APP_ID);
  u.searchParams.set("shorturl", surl);
  u.searchParams.set("root", dir ? "0" : "1");
  if (dir) u.searchParams.set("dir", dir);
  u.searchParams.set("scene", "");
  u.searchParams.set("web", "1");
  u.searchParams.set("page", "1");
  u.searchParams.set("num", "100");
  u.searchParams.set("channel", "dubox");
  u.searchParams.set("clienttype", "0");
  if (jsToken) u.searchParams.set("jsToken", jsToken);
  const { json } = await fetchText(u.toString(), {
    cookie,
    referer: `${ORIGIN}/sharing/link?surl=${surl}`,
  });
  return (json ?? { errno: -1 }) as TeraListJson;
}

/**
 * Streaming sign used by /share/streaming.
 * Confirmed live: sha1(uk + shareid + fid + unixTimestamp) → 40-hex, accepted
 * by 1024tera / terabox / terabox.app without a logged-in ndus cookie.
 */
export function teraboxStreamSign(uk: string, shareId: string, fid: string, timestamp: number): string {
  return createHash("sha1").update(`${uk}${shareId}${fid}${timestamp}`).digest("hex");
}

export function teraboxStreamUrl(file: Pick<ResolvedFile, "uk" | "shareId" | "fsId">, type = "M3U8_AUTO_480"): string | null {
  if (!file.uk || !file.shareId || !file.fsId) return null;
  const ts = Math.floor(Date.now() / 1000);
  const sign = teraboxStreamSign(file.uk, file.shareId, file.fsId, ts);
  const u = new URL(`${ORIGIN}/share/streaming`);
  u.searchParams.set("uk", file.uk);
  u.searchParams.set("shareid", file.shareId);
  u.searchParams.set("type", type);
  u.searchParams.set("fid", file.fsId);
  u.searchParams.set("sign", sign);
  u.searchParams.set("timestamp", String(ts));
  u.searchParams.set("app_id", APP_ID);
  u.searchParams.set("channel", "dubox");
  u.searchParams.set("clienttype", "0");
  u.searchParams.set("web", "1");
  return u.toString();
}

export async function fetchTeraboxPlaylist(
  uk: string,
  shareId: string,
  fid: string,
  type = "M3U8_AUTO_480",
): Promise<{ playlist: string; streamUrl: string } | { error: string }> {
  const types = [type, "M3U8_FLV_264_480", "M3U8_AUTO_360", "M3U8_FLV_264_360"];
  for (const t of types) {
    const streamUrl = teraboxStreamUrl({ uk, shareId, fsId: fid }, t);
    if (!streamUrl) continue;
    const { text, json } = await fetchText(streamUrl, { referer: `${ORIGIN}/` });
    if (typeof json === "object" && json && "errno" in json && (json as { errno: number }).errno !== 0) {
      continue;
    }
    if (text.includes("#EXTM3U")) return { playlist: text, streamUrl };
  }
  return { error: "No HLS playlist is available for this file yet (transcode pending or blocked)." };
}

/**
 * Original-quality dlink. Requires a live `ndus` cookie from a TeraBox account.
 * Without it the API returns errno -6 (need verify_v2) or errno 2.
 */
export async function fetchTeraboxDlink(opts: {
  uk: string;
  shareId: string;
  fsId: string;
  cookie: string;
  jsToken?: string;
}): Promise<string | null> {
  if (!opts.cookie.includes("ndus=")) return null;
  const u = new URL(`${ORIGIN}/api/sharedownload`);
  u.searchParams.set("app_id", APP_ID);
  u.searchParams.set("channel", "dubox");
  u.searchParams.set("clienttype", "0");
  u.searchParams.set("web", "1");
  if (opts.jsToken) u.searchParams.set("jsToken", opts.jsToken);
  const body = new URLSearchParams({
    product: "share",
    uk: opts.uk,
    primaryid: opts.shareId,
    fid_list: JSON.stringify([Number(opts.fsId)]),
  });
  const { json } = await fetchText(u.toString(), {
    method: "POST",
    body: body.toString(),
    cookie: opts.cookie,
    referer: `${ORIGIN}/`,
  });
  const data = json as { errno?: number; dlink?: string; list?: Array<{ dlink?: string }> } | null;
  if (!data || data.errno) return data?.list?.[0]?.dlink ?? data?.dlink ?? null;
  return data.list?.[0]?.dlink ?? data.dlink ?? null;
}

export async function resolveTerabox(rawUrl: string, extraCookie = ""): Promise<ResolveResult> {
  const started = Date.now();
  const surl = extractTeraSurl(rawUrl);
  if (!surl) {
    return {
      ok: false,
      host: "terabox",
      inputUrl: rawUrl,
      error: "Could not read a TeraBox share code from that URL.",
      hint: "Use a link like https://1024tera.com/s/… or https://www.terabox.com/sharing/link?surl=…",
      elapsedMs: Date.now() - started,
    };
  }

  const pageUrl = `${ORIGIN}/sharing/link?surl=${surl}`;
  const page = await fetchText(pageUrl, { cookie: extraCookie });
  const cookie = [page.cookie, extraCookie].filter(Boolean).join("; ");
  const jsToken = extractJsToken(page.text);

  let list = await listDir(surl, cookie, jsToken);
  if (list.errno && list.errno !== 0) {
    return {
      ok: false,
      host: "terabox",
      inputUrl: rawUrl,
      error: list.show_msg || `TeraBox refused the share (errno ${list.errno}).`,
      hint:
        list.errno === -9
          ? "This share is password-protected. Password support is on the roadmap."
          : list.errno === 2
            ? "The share expired or was taken down."
            : "Try again in a moment. If it keeps failing the share may be private.",
      elapsedMs: Date.now() - started,
    };
  }

  const shareId = String(list.share_id ?? "");
  const uk = String(list.uk ?? "");
  let items = list.list ?? [];

  // Folder shares return a single isdir=1 root — expand one level.
  if (items.length === 1 && String(items[0]?.isdir) === "1") {
    const nested = await listDir(surl, cookie, jsToken, items[0].path);
    if (nested.errno === 0 && nested.list?.length) items = nested.list;
  }

  const files = items.map((it) => toFile(it, { shareId, uk, surl }));
  const warnings: string[] = [];
  if (!extraCookie.includes("ndus=")) {
    warnings.push(
      "Original-quality download needs a TeraBox ndus cookie (optional, in Settings). Streaming still works without it.",
    );
  }
  if (files.length === 0) {
    warnings.push("The share opened but listed no files.");
  }

  return {
    ok: true,
    host: "terabox",
    inputUrl: rawUrl,
    title: (list.title || files[0]?.name || "TeraBox share").replace(/^\/+/, ""),
    files,
    warnings,
    usedCookie: extraCookie.includes("ndus="),
    elapsedMs: Date.now() - started,
  };
}
