export type HostKind = "terabox" | "diskwala" | "unknown";

export type ResolvedFile = {
  id: string;
  name: string;
  size: number;
  isDir: boolean;
  path: string;
  mimeHint: "video" | "audio" | "image" | "folder" | "file";
  thumbnail?: string;
  duration?: number;
  width?: number;
  height?: number;
  md5?: string;
  /** Host-specific ids used to mint stream / download URLs. */
  fsId?: string;
  shareId?: string;
  uk?: string;
  surl?: string;
  host: HostKind;
  /** Direct CDN URL when we already have one (Diskwala, or Terabox dlink). */
  directUrl?: string;
  /** True when original-quality dlink is present (usually needs ndus cookie). */
  originalReady: boolean;
  canStream: boolean;
};

export type ResolveOk = {
  ok: true;
  host: HostKind;
  inputUrl: string;
  title: string;
  files: ResolvedFile[];
  warnings: string[];
  usedCookie: boolean;
  elapsedMs: number;
};

export type ResolveErr = {
  ok: false;
  host: HostKind;
  inputUrl: string;
  error: string;
  hint?: string;
  elapsedMs: number;
};

export type ResolveResult = ResolveOk | ResolveErr;
