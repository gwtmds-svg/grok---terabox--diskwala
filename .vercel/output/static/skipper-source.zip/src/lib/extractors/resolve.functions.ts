import { createServerFn } from "@tanstack/react-start";
import { resolveShare } from "./index";

export const resolveLink = createServerFn({ method: "POST" })
  .validator((data: unknown) => {
    const d = data as { url?: string; cookie?: string };
    if (!d || typeof d.url !== "string") throw new Error("url is required");
    return { url: d.url, cookie: typeof d.cookie === "string" ? d.cookie : "" };
  })
  .handler(async ({ data }) => {
    return resolveShare(data.url, data.cookie);
  });
