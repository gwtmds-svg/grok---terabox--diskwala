import type { HostKind } from "./types";

const TERABOX_HOSTS = [
  "terabox.com",
  "terabox.app",
  "teraboxshare.com",
  "teraboxlink.com",
  "terasharelink.com",
  "terafileshare.com",
  "terasharefile.com",
  "1024tera.com",
  "1024terabox.com",
  "teraboxapp.com",
  "dubox.com",
  "freeterabox.com",
];

const DISKWALA_HOSTS = ["diskwala.com", "diskwala.app", "diskwala.net"];

function hostnameOf(raw: string): string | null {
  try {
    const u = new URL(raw.trim());
    return u.hostname.replace(/^www\./, "").toLowerCase();
  } catch {
    return null;
  }
}

export function detectHost(raw: string): HostKind {
  const host = hostnameOf(raw);
  if (!host) return "unknown";
  if (TERABOX_HOSTS.some((h) => host === h || host.endsWith(`.${h}`))) return "terabox";
  if (DISKWALA_HOSTS.some((h) => host === h || host.endsWith(`.${h}`))) return "diskwala";
  return "unknown";
}

/**
 * TeraBox short codes:
 *   https://1024tera.com/s/1XXXX  → surl = XXXX  (strip the leading 1)
 *   https://www.1024tera.com/sharing/link?surl=XXXX
 *   https://terabox.com/s/XXXX
 */
export function extractTeraSurl(raw: string): string | null {
  try {
    const u = new URL(raw.trim());
    const q = u.searchParams.get("surl");
    if (q) return normalizeSurl(q);
    const parts = u.pathname.split("/").filter(Boolean);
    const sIdx = parts.findIndex((p) => p === "s" || p === "share");
    if (sIdx >= 0 && parts[sIdx + 1]) return normalizeSurl(parts[sIdx + 1]);
    // /sharing/link is query-only; already handled
    return null;
  } catch {
    return null;
  }
}

function normalizeSurl(surl: string): string {
  const s = decodeURIComponent(surl).trim();
  // Official short links prefix a literal "1" in the /s/ path.
  if (/^1[\w-]{8,}/.test(s)) return s.slice(1);
  return s;
}

/** Diskwala share ids live at /app/:id (24-char hex) or /f/:id. */
export function extractDiskwalaId(raw: string): string | null {
  try {
    const u = new URL(raw.trim());
    const parts = u.pathname.split("/").filter(Boolean);
    const appIdx = parts.findIndex((p) => p === "app" || p === "f" || p === "file" || p === "v");
    if (appIdx >= 0 && parts[appIdx + 1]) return parts[appIdx + 1];
    const last = parts[parts.length - 1];
    if (last && /^[a-f0-9]{16,}$/i.test(last)) return last;
    return null;
  } catch {
    return null;
  }
}
