import type { ResolveResult } from "./types";
import { detectHost } from "./parse-url";
import { resolveTerabox } from "./terabox";
import { resolveDiskwala } from "./diskwala";

export type { ResolveResult, ResolveOk, ResolveErr, ResolvedFile, HostKind } from "./types";
export { detectHost, extractTeraSurl, extractDiskwalaId } from "./parse-url";
export { teraboxStreamUrl, fetchTeraboxPlaylist, fetchTeraboxDlink } from "./terabox";

export async function resolveShare(rawUrl: string, cookie = ""): Promise<ResolveResult> {
  const url = rawUrl.trim();
  if (!url) {
    return {
      ok: false,
      host: "unknown",
      inputUrl: rawUrl,
      error: "Paste a TeraBox or Diskwala link first.",
      elapsedMs: 0,
    };
  }
  const host = detectHost(url);
  if (host === "terabox") return resolveTerabox(url, cookie);
  if (host === "diskwala") return resolveDiskwala(url);
  return {
    ok: false,
    host: "unknown",
    inputUrl: url,
    error: "That host is not supported yet.",
    hint: "Skipper currently opens TeraBox (terabox.com, 1024tera.com, terabox.app, …) and Diskwala (diskwala.com) public share links.",
    elapsedMs: 0,
  };
}
