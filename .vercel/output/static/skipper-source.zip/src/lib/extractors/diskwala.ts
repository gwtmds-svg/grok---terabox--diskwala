import type { ResolveResult, ResolvedFile } from "./types";
import { extractDiskwalaId } from "./parse-url";

const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";
const PAGE = "https://www.diskwala.com";
const API = "https://ddudapidd.diskwala.com/api/v1/file/temp_info";

type DwFile = {
  id?: string;
  name?: string;
  filename?: string;
  title?: string;
  size?: number;
  contentLength?: number;
  mime?: string;
  mimeType?: string;
  thumbnail?: string;
  thumb?: string;
  poster?: string;
  url?: string;
  downloadUrl?: string;
  download_url?: string;
  signedUrl?: string;
  playbackUrl?: string;
  hls?: string;
  duration?: number;
  children?: DwFile[];
};

function asFile(raw: DwFile, id: string): ResolvedFile {
  const name = raw.name || raw.filename || raw.title || "Diskwala file";
  const url = raw.downloadUrl || raw.download_url || raw.signedUrl || raw.url || raw.playbackUrl;
  const mime = (raw.mime || raw.mimeType || "").toLowerCase();
  const hint: ResolvedFile["mimeHint"] = mime.startsWith("video")
    ? "video"
    : mime.startsWith("audio")
      ? "audio"
      : mime.startsWith("image")
        ? "image"
        : /\.(mp4|mkv|webm|mov)$/i.test(name)
          ? "video"
          : "file";
  return {
    id: raw.id || id,
    name,
    size: Number(raw.size || raw.contentLength || 0),
    isDir: Array.isArray(raw.children) && raw.children.length > 0,
    path: `/${name}`,
    mimeHint: hint,
    thumbnail: raw.thumbnail || raw.thumb || raw.poster,
    duration: raw.duration,
    host: "diskwala",
    directUrl: url,
    originalReady: Boolean(url),
    canStream: hint === "video" && Boolean(url || raw.hls),
  };
}

function parseTempInfo(json: unknown, id: string): ResolvedFile[] {
  if (!json || typeof json !== "object") return [];
  const root = json as Record<string, unknown>;
  const payload = (root.data ?? root.file ?? root.result ?? root) as DwFile;
  const files: ResolvedFile[] = [];
  if (Array.isArray(payload.children) && payload.children.length) {
    for (const child of payload.children) files.push(asFile(child, id));
  } else {
    files.push(asFile(payload, id));
  }
  return files.filter((f) => f.name);
}

/**
 * Diskwala wraps every API call with AppiCrypt (WASM anti-bot). A raw POST
 * returns 400 "Missing Appicrypt header". Replaying a captured header 403s
 * because the token is bound to the browser session + origin.
 *
 * Working path: load the public /app/:id page in Chromium and intercept
 * the temp_info JSON. The sample id 6a8d41a406ba7ea03d30ccb1 currently 404s
 * (file removed) — the extractor still reports that cleanly.
 */
async function interceptWithPlaywright(id: string): Promise<{ json: unknown; title: string; bodyText: string } | { error: string }> {
  try {
    const { chromium } = await import("playwright");
    const browser = await chromium.launch({
      headless: true,
      args: ["--no-sandbox", "--disable-dev-shm-usage"],
    });
    try {
      const page = await browser.newPage({
        userAgent: UA,
        viewport: { width: 1280, height: 800 },
      });
      let captured: unknown = null;
      page.on("response", async (res) => {
        const u = res.url();
        if (u.includes("temp_info") || u.includes("/file/sign") || u.includes("playlist_info")) {
          try {
            captured = await res.json();
          } catch {
            try {
              captured = { raw: (await res.text()).slice(0, 4000) };
            } catch {
              /* ignore */
            }
          }
        }
      });
      await page.goto(`${PAGE}/app/${id}`, { waitUntil: "domcontentloaded", timeout: 25000 });
      await page.waitForTimeout(8000);
      const title = await page.title();
      const bodyText = (await page.locator("body").innerText()).slice(0, 800);
      return { json: captured, title, bodyText };
    } finally {
      await browser.close();
    }
  } catch (err) {
    return { error: err instanceof Error ? err.message : String(err) };
  }
}

export async function resolveDiskwala(rawUrl: string): Promise<ResolveResult> {
  const started = Date.now();
  const id = extractDiskwalaId(rawUrl);
  if (!id) {
    return {
      ok: false,
      host: "diskwala",
      inputUrl: rawUrl,
      error: "Could not read a Diskwala file id from that URL.",
      hint: "Use a link like https://www.diskwala.com/app/<id>",
      elapsedMs: Date.now() - started,
    };
  }

  // Fast path: unsigned POST (almost always 400, but cheap to try).
  try {
    const res = await fetch(API, {
      method: "POST",
      headers: {
        "user-agent": UA,
        "content-type": "application/json",
        origin: PAGE,
        referer: `${PAGE}/app/${id}`,
        accept: "application/json",
      },
      body: JSON.stringify({ id }),
    });
    if (res.ok) {
      const json = await res.json();
      const files = parseTempInfo(json, id);
      if (files.length) {
        return {
          ok: true,
          host: "diskwala",
          inputUrl: rawUrl,
          title: files[0].name,
          files,
          warnings: [],
          usedCookie: false,
          elapsedMs: Date.now() - started,
        };
      }
    }
  } catch {
    /* fall through to Playwright */
  }

  const intercepted = await interceptWithPlaywright(id);
  if ("error" in intercepted) {
    return {
      ok: false,
      host: "diskwala",
      inputUrl: rawUrl,
      error: "Diskwala blocked the unsigned API (AppiCrypt). Browser intercept also failed.",
      hint: intercepted.error,
      elapsedMs: Date.now() - started,
    };
  }

  const text = `${intercepted.title}\n${intercepted.bodyText}`.toLowerCase();
  if (text.includes("not found") || text.includes("404") || text.includes("doesn't exist") || text.includes("does not exist")) {
    return {
      ok: false,
      host: "diskwala",
      inputUrl: rawUrl,
      error: "This Diskwala file is gone (removed or expired).",
      hint: "The extractor is working — paste a live /app/ link and it will intercept temp_info.",
      elapsedMs: Date.now() - started,
    };
  }

  const files = parseTempInfo(intercepted.json, id);
  if (!files.length) {
    return {
      ok: false,
      host: "diskwala",
      inputUrl: rawUrl,
      error: "Opened the Diskwala page but no file payload was returned.",
      hint: intercepted.title ? `Page title: ${intercepted.title}` : "The share may still be loading ads, or AppiCrypt rejected the session.",
      elapsedMs: Date.now() - started,
    };
  }

  return {
    ok: true,
    host: "diskwala",
    inputUrl: rawUrl,
    title: files[0].name,
    files,
    warnings: [],
    usedCookie: false,
    elapsedMs: Date.now() - started,
  };
}
