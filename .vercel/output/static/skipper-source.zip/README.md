# Skipper

Paste a TeraBox or Diskwala share link. See the files. Play or download them
without the ad wall.

## Status (2026-08-29)

- TeraBox listing: **working**, no login, live-tested on
  `https://1024tera.com/s/16-BFJ6KJhZEBpv_vhNsD6w`
- TeraBox in-browser HLS: **working**, sign = sha1(uk+shareid+fid+timestamp)
- TeraBox original file: **needs optional ndus cookie** (Settings)
- Diskwala: extractor **wired** (Playwright + AppiCrypt intercept). The sample
  id `6a8d41a406ba7ea03d30ccb1` is **expired / 404**.

## For the next builder

Read these in order:

1. [`docs/AI_HANDOFF_PROMPT.md`](docs/AI_HANDOFF_PROMPT.md) — paste this into a new AI chat
2. [`docs/COMPLETE_BUILD_GUIDE.md`](docs/COMPLETE_BUILD_GUIDE.md) — A–Z protocol, cookies, scaling

## Run

```
npm install
npm run dev
```

The app listens on port 8080. No database. No auth.

## Settings

Gear icon → optional `ndus=…` cookie from a logged-in TeraBox browser session.
Listing and playback work without it.
